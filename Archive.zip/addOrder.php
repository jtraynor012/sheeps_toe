<?php
    include "db.php";
    $post = file_get_contents('php://input');

    if (!$postdata){
        echo json_encode(["error" => "no data received"]);
        exit;
    }

    $request = json_decode($postdata);

    if ($request === null && json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(["error" => "JSON decoding error: " . json_last_error_msg()]);
        exit;
    }

    echo json_encode(["message" => "Hello from the other side"]);
?>